## Nano11 Post-setup redesign
### Features
- OS tweaks
- Install apps

## Projects used in the original post-setup
- [UninstallEdge.cmd by Vichingo455](https://gist.github.com/Vichingo455/39bb82496ef566156c8e65696051ce43)

## Notes
The official post-setup was ENTIRELY made by XPower7125.
